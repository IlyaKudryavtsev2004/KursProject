<?php
namespace app\controllers;
use yii\rest\ActiveController;
class KindController extends ActiveController
{
    public $modelClass = 'app\models\Kind';
}