<?php
namespace app\controllers;
use yii\rest\ActiveController;
class BasketController extends ActiveController
{
    public $modelClass = 'app\models\Basket';
}