<?php
namespace app\controllers;
use yii\rest\ActiveController;
class UserController extends ActiveController
{
    public $modelClass = 'app\models\User';

    public function actionCreate()
    {
        $data=Yii::$app->request->post();
        $user=new User();
        $user->load($data, '');
        
        if (!$user->validate()) return $user->errors;
        $user->password = Yii::$app->getSecurity()->generatePasswordHash($user->password);;
        $user->save();
        $response=$this->response;
        
        header('Access-Control-Allow-Origin: *');
        $response->statusCode=204;
        return $response;
 } 

}