<?php
namespace app\controllers;
use yii\rest\ActiveController;
class OrderController extends ActiveController
{
    public $modelClass = 'app\models\Order';
}