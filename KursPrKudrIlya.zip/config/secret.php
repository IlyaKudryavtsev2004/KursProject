<?php
const COOKIE_VALIDATION_KEY = 'iamsosecret';