<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "kind".
 *
 * @property int $id_kind
 * @property string $name_kind
 *
 * @property Product[] $products
 */
class Kind extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kind';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name_kind'], 'required'],
            [['name_kind'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_kind' => 'Id Kind',
            'name_kind' => 'Name Kind',
        ];
    }

    /**
     * Gets query for [[Products]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProducts()
    {
        return $this->hasMany(Product::class, ['id_kind' => 'id_kind']);
    }
}
