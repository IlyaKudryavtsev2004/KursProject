<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "product".
 *
 * @property int $id_product
 * @property string $name_product
 * @property int $id_kind
 *
 * @property Basket[] $baskets
 * @property Kind $kind
 * @property Quantity[] $quantities
 */
class Product extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'product';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name_product', 'id_kind'], 'required'],
            [['id_kind'], 'integer'],
            [['name_product'], 'string', 'max' => 255],
            [['id_kind'], 'exist', 'skipOnError' => true, 'targetClass' => Kind::class, 'targetAttribute' => ['id_kind' => 'id_kind']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_product' => 'Id Product',
            'name_product' => 'Name Product',
            'id_kind' => 'Id Kind',
        ];
    }

    /**
     * Gets query for [[Baskets]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBaskets()
    {
        return $this->hasMany(Basket::class, ['id_product' => 'id_product']);
    }

    /**
     * Gets query for [[Kind]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKind()
    {
        return $this->hasOne(Kind::class, ['id_kind' => 'id_kind']);
    }

    /**
     * Gets query for [[Quantities]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getQuantities()
    {
        return $this->hasMany(Quantity::class, ['id_product' => 'id_product']);
    }
}
